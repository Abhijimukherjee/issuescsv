const graphql = require("graphql-request");
const json2csv = require("json2csv");
const fs = require("fs");
const argv = require("minimist")(process.argv.slice(2));
const fileName = argv.filename || "issues.csv";

const fields = [
    {
        value: "node.title",
        label: "Tower | Issue Title",
    },
    {
        value: "node.author.login",
        label: "Issue Author"
    },
    {
        value: "node.state",
        label: "Issue Status"
    },

    {
        value: "node.milestone.title",
        label: "Sprint"
    },
    {
        value: "node.labels",
        label: "Category"
    },
    {
        value: "node.bodyText",
        label: "Issue Description"
    },
    {
        value: "node.comments",
        label: "Comments/Responses"
    },
    {
        value: "node.assignees.edges.node.login",
        label: "Assigned To"
    },
    {
        value: "node.createdAt",
        label: "Opened Date"
    },
    {
        value: "node.closedAt",
        label: "Closed Date"
    },
    {
        value: "node.url",
        label: "Issue URL"
    }
];

const client = new graphql.GraphQLClient("https://api.github.com/graphql", {
    headers: {
        Authorization: `Bearer ${argv.token}`
    }
});

const query = `{
  repository(owner: "${argv.owner}", name: "${argv.repo}") {
    issues(last: 10, orderBy: { field: UPDATED_AT, direction: DESC } ) {
      edges {
        node {
          assignees(first:1){
                edges {
                    node {
                        login
                        id
                    }
                }
          }
          title
          number
          state
          createdAt
          closedAt
          author {
            login
          }
          bodyText
          url
          milestone {
            id
            title
          }
          labels(first: 50) {
            edges {
              node {
                name
              }
            }
          }
          comments(first: 100) {
            edges {
              node {
                author {
                  avatarUrl
                  login
                  resourcePath
                  url
                }
                bodyText
                createdAt
              }
            }
          }
        }
      }
    }
  }
}`;

function writeCsvFile(csv) {
    fs.writeFile(fileName, csv, function (err) {
        if (err) throw err;
        console.log(`${fileName} file saved`);
    });
}

client
    .request(query)
    .then(data => {
        // For each issue
        data.repository.issues.edges.forEach(issue => {
            let commentsString = "";
            // For each comment
            issue.node.comments.edges.forEach(comment => {
                // Build a string of relevant field values
                commentsString += `[${comment.node.author.login}] - ${
                    comment.node.bodyText
                    }\n`;
            });
            // replace the comments object with the new string
            issue.node.comments = commentsString.slice(0,-1);
        });
        // For each issue
        data.repository.issues.edges.forEach(issue => {
            let labelsString = "";
            // For each label
            issue.node.labels.edges.forEach(label => {
                // Build a string of relevant field values
                labelsString += `${label.node.name} , `;
            });
            // replace the comments object with the new string
            issue.node.labels = labelsString.slice(0,-3);
        });

        const json2csvConfig = {
            data: data.repository.issues.edges,
            fields: fields,
            includeEmptyRows: true,
            preserveNewLinesInValues: true,

            unwindPath: ["node.labels.edges", "node.assignees.edges"]
        };

        json2csv(json2csvConfig, (err, csvString) => {
            writeCsvFile(csvString.replace(/[‘’]/g, `'`).replace(/[“”]/g, '"'));
        });
    })
    .catch(error => console.error(error));