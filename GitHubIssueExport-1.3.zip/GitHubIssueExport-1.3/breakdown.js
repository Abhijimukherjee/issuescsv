const query = `{
  repository(owner: "${argv.owner}", name: "${argv.repo}") {
    issues(last: 100) {
                        edges {
                                node {
                                      title
                                      number
                                      state
                                      author {login}
                                      bodyText
                                      url
                                      milestone {id
                                                 title}
                                      assignees{edges{
                                                        node {login}
                                                        }
                                                 }
                                      labels(first: 10) {
                                                         edges {
                                                                node {name}
                                                               }
                                                         }
                                      comments(last: 5) {
                                                          edges {
                                                                node {
                                                                       author {
                                                                                avatarUrl
                                                                                login
                                                                                resourcePath
                                                                                url
                                                                               }
                                                                       bodyText
                                                                       createdAt
                                                                      }
                                                                }
                                                          }
                                      }
                                }
                        }
    }
  }`;


assignees(first:1){
    edges {
        node {
            login
            id
        }
    }
}